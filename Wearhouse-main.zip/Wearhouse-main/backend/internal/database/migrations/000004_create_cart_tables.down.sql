-- Drop cart_items table first (because it references carts)
DROP TABLE IF EXISTS cart_items;

-- Drop carts table
DROP TABLE IF EXISTS carts; 